package object common {

  def ??? : Nothing = throw new Error("an implementation is missing")
  
  type ??? = Nothing
  
  type *** = Any
}